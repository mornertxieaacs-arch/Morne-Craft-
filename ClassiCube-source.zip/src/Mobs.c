#include "Mobs.h"
#include "Entity.h"
#include "EntityComponents.h"
#include "Model.h"
#include "World.h"
#include "Block.h"
#include "Game.h"
#include "Server.h"
#include "ExtMath.h"
#include "Vectors.h"
#include "Physics.h"
#include "Lighting.h"
#include "Graphics.h"
#include "Event.h"
#include "Chat.h"
#include "String_.h"
#include "Platform.h"

#define MOB_MAX      14
#define MOB_ID_BASE  200
#define MOB_SPAWN_TICKS 40
#define MOB_DESPAWN_DIST 52.0f

enum MobState { MS_IDLE, MS_WANDER, MS_CHASE, MS_FLEE };
enum MobKind  { MK_PIG, MK_SHEEP, MK_CHICKEN, MK_ZOMBIE, MK_SKELETON, MK_SPIDER, MK_CREEPER, MK_COUNT };

struct MobDef {
	const char* model;
	cc_bool hostile;
	float speed;   /* blocks per tick */
	int   health;
};
static const struct MobDef mob_defs[MK_COUNT] = {
	{ "pig",      false, 0.060f, 3 },
	{ "sheep",    false, 0.055f, 3 },
	{ "chicken",  false, 0.065f, 2 },
	{ "zombie",   true,  0.085f, 5 },
	{ "skeleton", true,  0.080f, 4 },
	{ "spider",   true,  0.120f, 4 },
	{ "creeper",  true,  0.075f, 3 }
};

struct Mob {
	struct Entity Base;
	cc_bool alive;
	int kind, state, health;
	int timer;       /* ticks left in current state */
	int attackCool;  /* ticks until next melee hit */
	int fuse;        /* creeper fuse ticks, -1 when not lit */
	float wanderYaw;
};
static struct Mob mobs[MOB_MAX];
static RNGState mob_rnd;
static int spawn_timer;

/*########################################################################################################################*
*------------------------------------------------------Helpers------------------------------------------------------------*
*#########################################################################################################################*/
static cc_bool Mob_SolidAt(int x, int y, int z) {
	BlockID b;
	if (y < 0) return true;
	if (y >= World.Height) return false;
	if (x < 0 || z < 0 || x >= World.Width || z >= World.Length) return true;
	b = World_GetBlock(x, y, z);
	return Blocks.Collide[b] == COLLIDE_SOLID || Blocks.Collide[b] == COLLIDE_ICE || Blocks.Collide[b] == COLLIDE_SLIPPERY_ICE;
}

static cc_bool Mob_Blocked(const Vec3* pos, const Vec3* size) {
	int x0 = (int)Math_Floor(pos->x - size->x * 0.5f), x1 = (int)Math_Floor(pos->x + size->x * 0.5f);
	int y0 = (int)Math_Floor(pos->y),                  y1 = (int)Math_Floor(pos->y + size->y);
	int z0 = (int)Math_Floor(pos->z - size->z * 0.5f), z1 = (int)Math_Floor(pos->z + size->z * 0.5f);
	int x, y, z;
	for (y = y0; y <= y1; y++)
		for (z = z0; z <= z1; z++)
			for (x = x0; x <= x1; x++)
				if (Mob_SolidAt(x, y, z)) return true;
	return false;
}

static cc_bool Mob_InWater(struct Entity* e) {
	int x = (int)Math_Floor(e->Position.x), y = (int)Math_Floor(e->Position.y + 0.3f), z = (int)Math_Floor(e->Position.z);
	if (!World_Contains(x, y, z)) return false;
	return Blocks.Collide[World_GetBlock(x, y, z)] == COLLIDE_WATER;
}

static float Mob_Dist2D(struct Entity* a, struct Entity* b) {
	float dx = a->Position.x - b->Position.x, dz = a->Position.z - b->Position.z;
	return Math_SqrtF(dx * dx + dz * dz);
}

static float Mob_YawTo(float dx, float dz) {
	return Math_Atan2f(-dz, dx) * MATH_RAD2DEG;
}

/*########################################################################################################################*
*-------------------------------------------------------Entity VTABLE-----------------------------------------------------*
*#########################################################################################################################*/
static PackedCol Mob_GetCol(struct Entity* e) {
	Vec3 eyePos = Entity_GetEyePosition(e);
	IVec3 pos; IVec3_Floor(&pos, &eyePos);
	return Lighting.Color(pos.x, pos.y, pos.z);
}

static void Mob_Despawn(struct Entity* e) {
	if (e->Flags & ENTITY_FLAG_HAS_MODELVB) Gfx_DeleteScratchVb(&e->ModelVB);
}

static void Mob_SetLocation(struct Entity* e, struct LocationUpdate* update) { }
static cc_bool Mob_ShouldRenderName(struct Entity* e) { return false; }

static void Mob_RenderModel(struct Entity* e, float delta, float t) {
	Vec3_Lerp(&e->Position, &e->prev.pos, &e->next.pos, t);
	Entity_LerpAngles(e, t);

	AnimatedComp_GetCurrent(e, t);
	e->ShouldRender = Model_ShouldRender(e);
	if (e->ShouldRender) Model_Render(e->Model, e);
}

static void Mob_Remove(struct Mob* m) {
	int i = (int)(m - mobs);
	m->alive = false;
	Entities_Remove(MOB_ID_BASE + i);
}

static void Mob_Explode(struct Mob* m) {
	struct Entity* p = &Entities.CurPlayer->Base;
	int cx = (int)Math_Floor(m->Base.Position.x), cy = (int)Math_Floor(m->Base.Position.y), cz = (int)Math_Floor(m->Base.Position.z);
	int x, y, z, r = 2;
	float dx, dy, dz, dist;

	for (y = -r; y <= r; y++)
		for (z = -r; z <= r; z++)
			for (x = -r; x <= r; x++) {
				BlockID b;
				if (x * x + y * y + z * z > r * r + 1) continue;
				if (!World_Contains(cx + x, cy + y, cz + z)) continue;
				b = World_GetBlock(cx + x, cy + y, cz + z);
				if (b == BLOCK_AIR || !Blocks.CanDelete[b]) continue;
				Game_ChangeBlock(cx + x, cy + y, cz + z, BLOCK_AIR);
			}

	dx = p->Position.x - m->Base.Position.x; dy = p->Position.y - m->Base.Position.y; dz = p->Position.z - m->Base.Position.z;
	dist = Math_SqrtF(dx * dx + dy * dy + dz * dz);
	if (dist < 6.0f && dist > 0.01f) {
		float k = (6.0f - dist) / 6.0f;
		p->Velocity.x += dx / dist * 0.9f * k;
		p->Velocity.y += 0.55f * k;
		p->Velocity.z += dz / dist * 0.9f * k;
	}
	Mob_Remove(m);
}

/*########################################################################################################################*
*-----------------------------------------------------------AI-----------------------------------------------------------*
*#########################################################################################################################*/
static void Mob_ChooseIdleOrWander(struct Mob* m) {
	if (Random_Next(&mob_rnd, 3) == 0) {
		m->state = MS_IDLE;   m->timer = 20 + Random_Next(&mob_rnd, 60);
	} else {
		m->state = MS_WANDER; m->timer = 30 + Random_Next(&mob_rnd, 80);
		m->wanderYaw = (float)Random_Next(&mob_rnd, 360);
	}
}

static void Mob_Think(struct Mob* m) {
	struct Entity* e = &m->Base;
	struct Entity* p = &Entities.CurPlayer->Base;
	const struct MobDef* def = &mob_defs[m->kind];
	float dist = Mob_Dist2D(e, p);
	float dy   = p->Position.y - e->Position.y;
	if (dy < 0) dy = -dy;

	m->timer--;
	if (m->attackCool > 0) m->attackCool--;

	if (def->hostile) {
		if (dist < 18.0f && dy < 8.0f) { m->state = MS_CHASE; }
		else if (m->state == MS_CHASE) { Mob_ChooseIdleOrWander(m); }

		if (m->kind == MK_CREEPER) {
			if (dist < 2.8f && dy < 2.0f) { if (m->fuse < 0) m->fuse = 30; }
			else if (dist > 4.5f) m->fuse = -1;
			if (m->fuse >= 0 && --m->fuse == 0) { Mob_Explode(m); return; }
		} else if (dist < 1.3f && dy < 1.8f && m->attackCool == 0) {
			/* melee: shove the player (no health system in classic) */
			float dx = p->Position.x - e->Position.x, dz = p->Position.z - e->Position.z;
			float len = Math_SqrtF(dx * dx + dz * dz); if (len < 0.01f) len = 1;
			p->Velocity.x += dx / len * 0.55f; p->Velocity.z += dz / len * 0.55f; p->Velocity.y += 0.25f;
			m->attackCool = 20;
		}
	} else if (m->state == MS_FLEE && m->timer <= 0) {
		Mob_ChooseIdleOrWander(m);
	}

	if (m->state != MS_CHASE && m->state != MS_FLEE && m->timer <= 0) Mob_ChooseIdleOrWander(m);
}

static void Mob_Move(struct Mob* m) {
	struct Entity* e = &m->Base;
	struct Entity* p = &Entities.CurPlayer->Base;
	const struct MobDef* def = &mob_defs[m->kind];
	Vec3 pos = e->Position, test;
	float speed = 0, yaw = e->Yaw, dx = 0, dz = 0, dist;
	cc_bool water = Mob_InWater(e);

	switch (m->state) {
	case MS_CHASE:
		dx = p->Position.x - e->Position.x; dz = p->Position.z - e->Position.z;
		dist = Math_SqrtF(dx * dx + dz * dz); if (dist < 0.01f) dist = 1;
		yaw = Mob_YawTo(dx, dz);
		speed = def->speed;
		if (m->kind == MK_SKELETON) { /* keeps its distance */
			if (dist < 5.0f) { dx = -dx; dz = -dz; }
			else if (dist < 9.0f) speed = 0;
		}
		if (m->kind == MK_CREEPER && m->fuse >= 0) speed = 0;
		dx /= dist; dz /= dist;
		break;
	case MS_FLEE:
		dx = e->Position.x - p->Position.x; dz = e->Position.z - p->Position.z;
		dist = Math_SqrtF(dx * dx + dz * dz); if (dist < 0.01f) dist = 1;
		dx /= dist; dz /= dist; yaw = Mob_YawTo(dx, dz); speed = def->speed * 1.6f;
		break;
	case MS_WANDER:
		yaw = m->wanderYaw;
		dx = Math_SinF(yaw * MATH_DEG2RAD); dz = -Math_CosF(yaw * MATH_DEG2RAD);
		speed = def->speed * 0.6f;
		break;
	default: break;
	}

	/* horizontal movement, one axis at a time */
	e->Velocity.x = dx * speed + e->Velocity.x * 0.5f;
	e->Velocity.z = dz * speed + e->Velocity.z * 0.5f;
	if (speed == 0) { e->Velocity.x *= 0.6f; e->Velocity.z *= 0.6f; }

	test = pos; test.x += e->Velocity.x;
	if (!Mob_Blocked(&test, &e->Size)) pos.x = test.x;
	else if (e->OnGround) { e->Velocity.y = 0.42f; }          /* hop up one block */
	test = pos; test.z += e->Velocity.z;
	if (!Mob_Blocked(&test, &e->Size)) pos.z = test.z;
	else if (e->OnGround) { e->Velocity.y = 0.42f; }

	/* vertical */
	if (water) { e->Velocity.y = e->Velocity.y * 0.8f + 0.02f; }
	else       { e->Velocity.y = (e->Velocity.y - 0.08f) * 0.98f; }
	test = pos; test.y += e->Velocity.y;
	if (!Mob_Blocked(&test, &e->Size)) { pos.y = test.y; e->OnGround = false; }
	else { if (e->Velocity.y < 0) e->OnGround = true; e->Velocity.y = 0; }

	/* push out of walls / fall protection */
	if (pos.y < -20) { Mob_Remove(m); return; }

	e->prev = e->next;
	e->next.pos = pos; e->next.yaw = yaw; e->next.pitch = 0;
	e->next.rotX = 0; e->next.rotY = 0; e->next.rotZ = 0;
	e->Position = pos;
	/* turn smoothly */
	{
		float diff = yaw - e->prev.yaw;
		while (diff >  180) diff -= 360;
		while (diff < -180) diff += 360;
		e->next.yaw = e->prev.yaw + diff * 0.35f;
	}
}

static void Mob_Tick(struct Entity* e, float delta) {
	struct Mob* m = (struct Mob*)e;
	struct Entity* p = &Entities.CurPlayer->Base;
	Mob_Think(m);
	if (!m->alive) return;
	Mob_Move(m);
	if (!m->alive) return;
	AnimatedComp_Update(e, e->prev.pos, e->next.pos, delta);
	if (Mob_Dist2D(e, p) > MOB_DESPAWN_DIST) Mob_Remove(m);
}

static const struct EntityVTABLE mob_VTABLE = {
	Mob_Tick, Mob_Despawn, Mob_SetLocation, Mob_GetCol, Mob_RenderModel, Mob_ShouldRenderName
};

/*########################################################################################################################*
*---------------------------------------------------Spawning / attacking--------------------------------------------------*
*#########################################################################################################################*/
static void Mobs_Clear(void) {
	int i;
	for (i = 0; i < MOB_MAX; i++) {
		if (mobs[i].alive) Mob_Remove(&mobs[i]);
	}
}

static int Mobs_Count(void) {
	int i, n = 0;
	for (i = 0; i < MOB_MAX; i++) if (mobs[i].alive) n++;
	return n;
}

static void Mobs_Spawn(int kind, float x, float y, float z) {
	int i;
	for (i = 0; i < MOB_MAX; i++) {
		struct Mob* m = &mobs[i];
		cc_string model;
		if (m->alive) continue;

		Mem_Set(m, 0, sizeof(struct Mob));
		Entity_Init(&m->Base);
		m->Base.VTABLE = &mob_VTABLE;
		m->Base.Flags |= ENTITY_FLAG_CLASSIC_ADJUST;
		model = String_FromReadonly(mob_defs[kind].model);
		Entity_SetModel(&m->Base, &model);
		AnimatedComp_Init(&m->Base.Anim);

		m->kind   = kind;
		m->health = mob_defs[kind].health;
		m->fuse   = -1;
		m->alive  = true;
		m->Base.Position.x = x; m->Base.Position.y = y; m->Base.Position.z = z;
		m->Base.prev.pos = m->Base.next.pos = m->Base.Position;
		Mob_ChooseIdleOrWander(m);

		Entities.List[MOB_ID_BASE + i] = &m->Base;
		return;
	}
}

static void Mobs_TrySpawn(void) {
	struct Entity* p = &Entities.CurPlayer->Base;
	int tries, kind;
	for (tries = 0; tries < 6; tries++) {
		float ang  = (float)Random_Next(&mob_rnd, 360) * MATH_DEG2RAD;
		float dist = 14.0f + (float)Random_Next(&mob_rnd, 14);
		int x = (int)Math_Floor(p->Position.x + Math_SinF(ang) * dist);
		int z = (int)Math_Floor(p->Position.z - Math_CosF(ang) * dist);
		int y;
		if (x < 1 || z < 1 || x >= World.Width - 1 || z >= World.Length - 1) continue;

		for (y = World.Height - 2; y > 0; y--) {
			if (Mob_SolidAt(x, y, z)) break;
		}
		if (y <= 0) continue;
		if (Mob_SolidAt(x, y + 1, z) || Mob_SolidAt(x, y + 2, z)) continue;
		if (Blocks.Collide[World_GetBlock(x, y + 1, z)] != COLLIDE_NONE) continue;

		kind = Random_Next(&mob_rnd, 100) < 45 ? (MK_ZOMBIE + Random_Next(&mob_rnd, 4)) : Random_Next(&mob_rnd, 3);
		Mobs_Spawn(kind, x + 0.5f, (float)(y + 1), z + 0.5f);
		return;
	}
}

cc_bool Mobs_TryAttack(void) {
	struct Entity* p = &Entities.CurPlayer->Base;
	int id = Entities_GetClosest(p), i;
	struct Mob* m;
	float dx, dz, len;
	if (id < MOB_ID_BASE || id >= MOB_ID_BASE + MOB_MAX) return false;

	i = id - MOB_ID_BASE; m = &mobs[i];
	if (!m->alive) return false;
	if (Mob_Dist2D(&m->Base, p) > 4.5f) return false;

	dx = m->Base.Position.x - p->Position.x; dz = m->Base.Position.z - p->Position.z;
	len = Math_SqrtF(dx * dx + dz * dz); if (len < 0.01f) len = 1;
	m->Base.Velocity.x += dx / len * 0.5f; m->Base.Velocity.z += dz / len * 0.5f;
	m->Base.Velocity.y  = 0.32f;

	m->health--;
	if (m->health <= 0) { Mob_Remove(m); return true; }
	if (!mob_defs[m->kind].hostile) { m->state = MS_FLEE; m->timer = 80; }
	return true;
}

/*########################################################################################################################*
*---------------------------------------------------------Component-------------------------------------------------------*
*#########################################################################################################################*/
static void Mobs_OnNewMap(void) { Mobs_Clear(); spawn_timer = 100; }
static void Mobs_Reset(void)    { Mobs_Clear(); }
static void Mobs_Free(void)     { Mobs_Clear(); }

static void Mobs_Init(void) {
	Mem_Set(mobs, 0, sizeof(mobs));
	Random_SeedFromCurrentTime(&mob_rnd);
	spawn_timer = 100;
}

/* Called every entity tick from Entities_Tick */
void Mobs_Tick(void) {
	if (!Server.IsSinglePlayer || !World.Loaded || Game_ClassicMode) return;
	if (--spawn_timer > 0) return;
	spawn_timer = MOB_SPAWN_TICKS;
	if (Mobs_Count() < MOB_MAX - 2) Mobs_TrySpawn();
}

struct IGameComponent Mobs_Component = {
	Mobs_Init, Mobs_Free, Mobs_Reset, Mobs_OnNewMap
};
