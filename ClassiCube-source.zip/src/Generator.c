#include "Generator.h"
#include "BlockID.h"
#include "ExtMath.h"
#include "Funcs.h"
#include "Platform.h"
#include "World.h"
#include "Utils.h"
#include "Game.h"
#include "Screens.h"
#include "Window.h"
#include "Entity.h"
#include "Lighting.h"
#include "MapRenderer.h"
#include "EnvRenderer.h"
#include "BlockPhysics.h"
#include "Block.h"
#include "Constants.h"

static const struct MapGenerator* gen_active;
BlockRaw* Gen_Blocks;

volatile float Gen_CurrentProgress;
volatile const char* Gen_CurrentState;
volatile static cc_bool gen_done;

/* There are two main types of multitasking: */
/*  - Pre-emptive multitasking (system automatically switches between threads) */
/*  - Cooperative multitasking (threads must be manually switched by the app) */
/*                                                                             */
/* Systems only supporting cooperative multitasking can be problematic though: */
/*   If the whole map generation was performed as a single function call, */
/*     then the game thread would not get run at all until map generation */
/*     completed - which is not a great user experience. */
/*   To avoid that, on these systems, map generation may be divided into */
/*     a series of steps so that ClassiCube can periodically switch back */
/*     to the game thread to ensure that the game itself still (slowly) runs. */
#ifdef CC_BUILD_COOPTHREADED
static int gen_step;
static cc_uint64 lastRender;

#define GEN_COOP_BEGIN \
	cc_uint64 curTime; \
	switch (gen_step) {

#define GEN_COOP_STEP(index, step) \
	case index: \
		step; \
		gen_step++; \
		curTime = Stopwatch_Measure(); \
		if (Stopwatch_ElapsedMS(lastRender, curTime) > 100) { lastRender = curTime; return; }
		/* Switch back to game thread if more than 100 milliseconds since it was last run */

#define GEN_COOP_END \
	}

static void Gen_Run(void) {
	gen_step = 0;
	lastRender = Stopwatch_Measure();
	gen_active->Generate();
}

cc_bool Gen_IsDone(void) {
	/* Resume map generation if incomplete */
	if (!gen_done) gen_active->Generate();
	return gen_done;
}
#else
/* For systems supporting preemptive threading, there's no point */
/* bothering with all the cooperative tasking shenanigans */
#define GEN_COOP_BEGIN
#define GEN_COOP_STEP(index, step) step;
#define GEN_COOP_END

static void Gen_DoGen(void) {
	gen_active->Generate();
}

static void Gen_Run(void) {
	void* thread;
	Thread_Run(&thread, Gen_DoGen, 128 * 1024, "Map gen");
	Thread_Detach(thread);
}

cc_bool Gen_IsDone(void) { return gen_done; }
#endif

static void Gen_Reset(void) {
	Gen_CurrentProgress = 0.0f;
	Gen_CurrentState    = "";
	gen_done = false;
}

void Gen_Start(const struct MapGenerator* gen, int seed,
				int width, int height, int length) {	
	World_NewMap();
	World_SetDimensions(width, height, length);
	World.Seed = seed;

	gen_active = gen;
	Gen_Reset();
	Gen_Blocks = (BlockRaw*)Mem_TryAlloc(World.Volume, 1);

	if (!Gen_Blocks || !gen->Prepare(seed)) {
		Window_ShowDialog("Out of memory", "Not enough free memory to generate a map that large.\nTry a smaller size.");
		gen_done = true;
	} else {
		Gen_Run();
	}

	GeneratingScreen_Show();
}


/*########################################################################################################################*
*-----------------------------------------------------Flatgrass gen-------------------------------------------------------*
*#########################################################################################################################*/
static void FlatgrassGen_MapSet(int yBeg, int yEnd, BlockRaw block) {
	cc_uint32 oneY = (cc_uint32)World.OneY;
	BlockRaw* ptr = Gen_Blocks;
	int y, yHeight;

	yBeg = max(yBeg, 0); yEnd = max(yEnd, 0);
	yHeight = (yEnd - yBeg) + 1;
	Gen_CurrentProgress = 0.0f;

	for (y = yBeg; y <= yEnd; y++) {
		Mem_Set(ptr + y * oneY, block, oneY);
		Gen_CurrentProgress = (float)(y - yBeg) / yHeight;
	}
}

static cc_bool FlatgrassGen_Prepare(int seed) {
	return true;
}

static void FlatgrassGen_Generate(void) {
	Gen_CurrentState = "Setting air blocks";
	FlatgrassGen_MapSet(World.Height / 2, World.MaxY, BLOCK_AIR);

	Gen_CurrentState = "Setting dirt blocks";
	FlatgrassGen_MapSet(0, World.Height / 2 - 2, BLOCK_DIRT);

	Gen_CurrentState = "Setting grass blocks";
	FlatgrassGen_MapSet(World.Height / 2 - 1, World.Height / 2 - 1, BLOCK_GRASS);

	gen_done = true;
}

const struct MapGenerator FlatgrassGen = {
	FlatgrassGen_Prepare,
	FlatgrassGen_Generate
};


/*########################################################################################################################*
*---------------------------------------------------Noise generation------------------------------------------------------*
*#########################################################################################################################*/
#define NOISE_TABLE_SIZE 512
static void ImprovedNoise_Init(cc_uint8* p, RNGState* rnd) {
	cc_uint8 tmp;
	int i, j;
	for (i = 0; i < 256; i++) { p[i] = i; }

	/* shuffle randomly using fisher-yates */
	for (i = 0; i < 256; i++) {
		j   = Random_Range(rnd, i, 256);
		tmp = p[i]; p[i] = p[j]; p[j] = tmp;
	}

	for (i = 0; i < 256; i++) {
		p[i + 256] = p[i];
	}
}

/* Normally, calculating Grad involves a function call + switch. However, the table combinations
  can be directly packed into a set of bit flags (where each 2 bit combination indicates either -1, 0 1).
  This avoids needing to call another function that performs branching */
#define X_FLAGS 0x46552222
#define Y_FLAGS 0x2222550A
#define Grad(hash, x, y) (((X_FLAGS >> (hash)) & 3) - 1) * (x) + (((Y_FLAGS >> (hash)) & 3) - 1) * (y);

static float ImprovedNoise_Calc(const cc_uint8* p, float x, float y) {
	int xFloor, yFloor, X, Y;
	float u, v;
	int A, B, hash;
	float g22, g12, c1;
	float g21, g11, c2;

	xFloor = x >= 0 ? (int)x : (int)x - 1;
	yFloor = y >= 0 ? (int)y : (int)y - 1;
	X = xFloor & 0xFF; Y = yFloor & 0xFF;
	x -= xFloor;       y -= yFloor;

	u = x * x * x * (x * (x * 6 - 15) + 10); /* Fade(x) */
	v = y * y * y * (y * (y * 6 - 15) + 10); /* Fade(y) */
	A = p[X] + Y; B = p[X + 1] + Y;

	hash = (p[p[A]] & 0xF) << 1;
	g22  = Grad(hash, x,     y); /* Grad(p[p[A], x,     y) */
	hash = (p[p[B]] & 0xF) << 1;
	g12  = Grad(hash, x - 1, y); /* Grad(p[p[B], x - 1, y) */
	c1   = g22 + u * (g12 - g22);

	hash = (p[p[A + 1]] & 0xF) << 1;
	g21  = Grad(hash, x,     y - 1); /* Grad(p[p[A + 1], x,     y - 1) */
	hash = (p[p[B + 1]] & 0xF) << 1;
	g11  = Grad(hash, x - 1, y - 1); /* Grad(p[p[B + 1], x - 1, y - 1) */
	c2   = g21 + u * (g11 - g21);

	return c1 + v * (c2 - c1);
}


struct OctaveNoise { cc_uint8 p[8][NOISE_TABLE_SIZE]; int octaves; };
static void OctaveNoise_Init(struct OctaveNoise* n, RNGState* rnd, int octaves) {
	int i;
	n->octaves = octaves;
	
	for (i = 0; i < octaves; i++) {
		ImprovedNoise_Init(n->p[i], rnd);
	}
}

static float OctaveNoise_Calc(const struct OctaveNoise* n, float x, float y) {
	float amplitude = 1, freq = 1;
	float sum = 0;
	int i;

	for (i = 0; i < n->octaves; i++) {
		sum += ImprovedNoise_Calc(n->p[i], x * freq, y * freq) * amplitude;
		amplitude *= 2.0f;
		freq *= 0.5f;
	}
	return sum;
}


struct CombinedNoise { struct OctaveNoise noise1, noise2; };
static void CombinedNoise_Init(struct CombinedNoise* n, RNGState* rnd, int octaves1, int octaves2) {
	OctaveNoise_Init(&n->noise1, rnd, octaves1);
	OctaveNoise_Init(&n->noise2, rnd, octaves2);
}

static float CombinedNoise_Calc(const struct CombinedNoise* n, float x, float y) {
	float offset = OctaveNoise_Calc(&n->noise2, x, y);
	return OctaveNoise_Calc(&n->noise1, x + offset, y);
}


/*########################################################################################################################*
*----------------------------------------------------Notchy map gen-------------------------------------------------------*
*#########################################################################################################################*/
static int waterLevel, minHeight;
static cc_int16* heightmap;
static RNGState rnd;

static void NotchyGen_FillOblateSpheroid(int x, int y, int z, float radius, BlockRaw block) {
	int xBeg = Math_Floor(max(x - radius, 0));
	int xEnd = Math_Floor(min(x + radius, World.MaxX));
	int yBeg = Math_Floor(max(y - radius, 0));
	int yEnd = Math_Floor(min(y + radius, World.MaxY));
	int zBeg = Math_Floor(max(z - radius, 0));
	int zEnd = Math_Floor(min(z + radius, World.MaxZ));

	float radiusSq = radius * radius;
	int index;
	int xx, yy, zz, dx, dy, dz;

	for (yy = yBeg; yy <= yEnd; yy++) { dy = yy - y;
		for (zz = zBeg; zz <= zEnd; zz++) { dz = zz - z;
			for (xx = xBeg; xx <= xEnd; xx++) { dx = xx - x;

				if ((dx * dx + 2 * dy * dy + dz * dz) < radiusSq) {
					index = World_Pack(xx, yy, zz);
					if (Gen_Blocks[index] == BLOCK_STONE)
						Gen_Blocks[index] = block;
				}
			}
		}
	}
}

#if CC_BUILD_MAXSTACK <= (32 * 1024)
	#define STACK_FAST 512
#else
	#define STACK_FAST 8192
#endif

static void NotchyGen_FloodFill(int index, BlockRaw block) {
	int* stack;
	int stack_default[STACK_FAST]; /* avoid allocating memory if possible */
	int count = 0, limit = STACK_FAST;
	int x, y, z;

	stack = stack_default;
	if (index < 0) return; /* y below map, don't bother starting */
	stack[count++] = index;

	while (count) {
		index = stack[--count];

		if (Gen_Blocks[index] != BLOCK_AIR) continue;
		Gen_Blocks[index] = block;

		x = index  % World.Width;
		y = index  / World.OneY;
		z = (index / World.Width) % World.Length;

		/* need to increase stack */
		if (count >= limit - FACE_COUNT) {
			Utils_Resize((void**)&stack, &limit, 4, STACK_FAST, STACK_FAST);
		}

		if (x > 0)          { stack[count++] = index - 1; }
		if (x < World.MaxX) { stack[count++] = index + 1; }
		if (z > 0)          { stack[count++] = index - World.Width; }
		if (z < World.MaxZ) { stack[count++] = index + World.Width; }
		if (y > 0)          { stack[count++] = index - World.OneY; }
	}
	if (limit > STACK_FAST) Mem_Free(stack);
}


static void NotchyGen_CreateHeightmap(void) {
	float hLow, hHigh, height;
	int hIndex = 0, adjHeight;
	int x, z;

#if CC_BUILD_MAXSTACK <= (16 * 1024)
	struct NoiseBuffer { 
		struct CombinedNoise n1, n2;
		struct OctaveNoise n3;
	};
	void* mem = TempMem_Alloc(sizeof(struct NoiseBuffer));

	struct NoiseBuffer* buf  = (struct NoiseBuffer*)mem;
	struct CombinedNoise* n1 = &buf->n1;
	struct CombinedNoise* n2 = &buf->n2;
	struct OctaveNoise*   n3 = &buf->n3;
#else
	struct CombinedNoise _n1, *n1 = &_n1;
	struct CombinedNoise _n2, *n2 = &_n2;
	struct OctaveNoise   _n3, *n3 = &_n3;
#endif

	CombinedNoise_Init(n1, &rnd, 8, 8);
	CombinedNoise_Init(n2, &rnd, 8, 8);	
	OctaveNoise_Init(n3,   &rnd, 6);

	Gen_CurrentState = "Building heightmap";
	for (z = 0; z < World.Length; z++) {
		Gen_CurrentProgress = (float)z / World.Length;

		for (x = 0; x < World.Width; x++) {
			hLow   = CombinedNoise_Calc(n1, x * 1.3f, z * 1.3f) / 6 - 4;
			height = hLow;

			if (OctaveNoise_Calc(n3, (float)x, (float)z) <= 0) {
				hHigh = CombinedNoise_Calc(n2, x * 1.3f, z * 1.3f) / 5 + 6;
				height = max(hLow, hHigh);
			}

			height *= 0.5f;
			if (height < 0) height *= 0.8f;

			adjHeight = (int)(height + waterLevel);
			minHeight = min(adjHeight, minHeight);
			heightmap[hIndex++] = adjHeight;
		}
	}
}

static int NotchyGen_CreateStrataFast(void) {
	cc_uint32 oneY = (cc_uint32)World.OneY;
	int stoneHeight, airHeight;
	int y;

	Gen_CurrentProgress = 0.0f;
	Gen_CurrentState    = "Filling map";
	/* Make lava layer at bottom */
	Mem_Set(Gen_Blocks, BLOCK_STILL_LAVA, oneY);

	/* Invariant: the lowest value dirtThickness can possible be is -14 */
	stoneHeight = minHeight - 14;
	/* We can quickly fill in bottom solid layers */
	for (y = 1; y <= stoneHeight; y++) {
		Mem_Set(Gen_Blocks + y * oneY, BLOCK_STONE, oneY);
		Gen_CurrentProgress = (float)y / World.Height;
	}

	/* Fill in rest of map wih air */
	airHeight = max(0, stoneHeight) + 1;
	for (y = airHeight; y < World.Height; y++) {
		Mem_Set(Gen_Blocks + y * oneY, BLOCK_AIR, oneY);
		Gen_CurrentProgress = (float)y / World.Height;
	}

	/* if stoneHeight is <= 0, then no layer is fully stone */
	return max(stoneHeight, 1);
}

static void NotchyGen_CreateStrata(void) {
	int dirtThickness, dirtHeight;
	int minStoneY, stoneHeight;
	int hIndex = 0, maxY = World.MaxY, index = 0;
	int x, y, z;
	struct OctaveNoise n;

	/* Try to bulk fill bottom of the map if possible */
	minStoneY = NotchyGen_CreateStrataFast();
	OctaveNoise_Init(&n, &rnd, 8);

	Gen_CurrentState = "Creating strata";
	for (z = 0; z < World.Length; z++) {
		Gen_CurrentProgress = (float)z / World.Length;

		for (x = 0; x < World.Width; x++) {
			dirtThickness = (int)(OctaveNoise_Calc(&n, (float)x, (float)z) / 24 - 4);
			dirtHeight    = heightmap[hIndex++];
			stoneHeight   = dirtHeight + dirtThickness;

			stoneHeight = min(stoneHeight, maxY);
			dirtHeight  = min(dirtHeight,  maxY);

			index = World_Pack(x, minStoneY, z);
			for (y = minStoneY; y <= stoneHeight; y++) {
				Gen_Blocks[index] = BLOCK_STONE; index += World.OneY;
			}

			stoneHeight = max(stoneHeight, 0);
			index = World_Pack(x, (stoneHeight + 1), z);
			for (y = stoneHeight + 1; y <= dirtHeight; y++) {
				Gen_Blocks[index] = BLOCK_DIRT; index += World.OneY;
			}
		}
	}
}

static void NotchyGen_CarveCaves(void) {
	int cavesCount, caveLen;
	float caveX, caveY, caveZ;
	float theta, deltaTheta, phi, deltaPhi;
	float caveRadius, radius;
	int cenX, cenY, cenZ;
	int i, j;

	cavesCount       = World.Volume / 8192;
	Gen_CurrentState = "Carving caves";
	for (i = 0; i < cavesCount; i++) {
		Gen_CurrentProgress = (float)i / cavesCount;

		caveX = (float)Random_Next(&rnd, World.Width);
		caveY = (float)Random_Next(&rnd, World.Height);
		caveZ = (float)Random_Next(&rnd, World.Length);

		caveLen = (int)((Random_Float(&rnd) + Random_Float(&rnd)) * 200.0f);
		theta   = Random_Float(&rnd) * 2.0f * MATH_PI; deltaTheta = 0.0f;
		phi     = Random_Float(&rnd) * 2.0f * MATH_PI; deltaPhi   = 0.0f;
		caveRadius = Random_Float(&rnd) * Random_Float(&rnd);

		for (j = 0; j < caveLen; j++) {
			caveX += Math_SinF(theta) * Math_CosF(phi);
			caveZ += Math_CosF(theta) * Math_CosF(phi);
			caveY += Math_SinF(phi);

			theta      = theta + deltaTheta * 0.2f;
			deltaTheta = deltaTheta * 0.9f + Random_Float(&rnd) - Random_Float(&rnd);
			phi        = phi * 0.5f + deltaPhi * 0.25f;
			deltaPhi   = deltaPhi  * 0.75f + Random_Float(&rnd) - Random_Float(&rnd);
			if (Random_Float(&rnd) < 0.25f) continue;

			cenX = (int)(caveX + (Random_Next(&rnd, 4) - 2) * 0.2f);
			cenY = (int)(caveY + (Random_Next(&rnd, 4) - 2) * 0.2f);
			cenZ = (int)(caveZ + (Random_Next(&rnd, 4) - 2) * 0.2f);

			radius = (World.Height - cenY) / (float)World.Height;
			radius = 1.2f + (radius * 3.5f + 1.0f) * caveRadius;
			radius = radius * Math_SinF(j * MATH_PI / caveLen);
			NotchyGen_FillOblateSpheroid(cenX, cenY, cenZ, radius, BLOCK_AIR);
		}
	}
}

static void NotchyGen_CarveOreVeins(float abundance, const char* state, BlockRaw block) {
	int numVeins, veinLen;
	float veinX, veinY, veinZ;
	float theta, deltaTheta, phi, deltaPhi;
	float radius;
	int i, j;

	numVeins         = (int)(World.Volume * abundance / 16384);
	Gen_CurrentState = state;
	for (i = 0; i < numVeins; i++) {
		Gen_CurrentProgress = (float)i / numVeins;

		veinX = (float)Random_Next(&rnd, World.Width);
		veinY = (float)Random_Next(&rnd, World.Height);
		veinZ = (float)Random_Next(&rnd, World.Length);

		veinLen = (int)(Random_Float(&rnd) * Random_Float(&rnd) * 75 * abundance);
		theta = Random_Float(&rnd) * 2.0f * MATH_PI; deltaTheta = 0.0f;
		phi   = Random_Float(&rnd) * 2.0f * MATH_PI; deltaPhi   = 0.0f;

		for (j = 0; j < veinLen; j++) {
			veinX += Math_SinF(theta) * Math_CosF(phi);
			veinZ += Math_CosF(theta) * Math_CosF(phi);
			veinY += Math_SinF(phi);

			theta      = deltaTheta * 0.2f;
			deltaTheta = deltaTheta * 0.9f + Random_Float(&rnd) - Random_Float(&rnd);
			phi        = phi * 0.5f + deltaPhi * 0.25f;
			deltaPhi   = deltaPhi   * 0.9f + Random_Float(&rnd) - Random_Float(&rnd);

			radius = abundance * Math_SinF(j * MATH_PI / veinLen) + 1.0f;
			NotchyGen_FillOblateSpheroid((int)veinX, (int)veinY, (int)veinZ, radius, block);
		}
	}
}

static void NotchyGen_FloodFillWaterBorders(void) {
	int waterY = waterLevel - 1;
	int index1, index2;
	int x, z;
	Gen_CurrentState = "Flooding edge water";

	index1 = World_Pack(0, waterY, 0);
	index2 = World_Pack(0, waterY, World.Length - 1);
	for (x = 0; x < World.Width; x++) {
		Gen_CurrentProgress = 0.0f + ((float)x / World.Width) * 0.5f;

		NotchyGen_FloodFill(index1, BLOCK_STILL_WATER);
		NotchyGen_FloodFill(index2, BLOCK_STILL_WATER);
		index1++; index2++;
	}

	index1 = World_Pack(0,             waterY, 0);
	index2 = World_Pack(World.Width - 1, waterY, 0);
	for (z = 0; z < World.Length; z++) {
		Gen_CurrentProgress = 0.5f + ((float)z / World.Length) * 0.5f;

		NotchyGen_FloodFill(index1, BLOCK_STILL_WATER);
		NotchyGen_FloodFill(index2, BLOCK_STILL_WATER);
		index1 += World.Width; index2 += World.Width;
	}
}

static void NotchyGen_FloodFillWater(void) {
	int numSources;
	int i, x, y, z;

	numSources       = World.Width * World.Length / 8000;
	Gen_CurrentState = "Flooding water";
	for (i = 0; i < numSources; i++) {
		Gen_CurrentProgress = (float)i / numSources;

		x = Random_Next(&rnd, World.Width);
		z = Random_Next(&rnd, World.Length);
		y = waterLevel - Random_Range(&rnd, 1, 3);
		NotchyGen_FloodFill(World_Pack(x, y, z), BLOCK_STILL_WATER);
	}
}

static void NotchyGen_FloodFillLava(void) {
	int numSources;
	int i, x, y, z;

	numSources       = World.Width * World.Height * World.Length / 20000;
	Gen_CurrentState = "Flooding lava";
	for (i = 0; i < numSources; i++) {
		Gen_CurrentProgress = (float)i / numSources;

		x = Random_Next(&rnd, World.Width);
		z = Random_Next(&rnd, World.Length);
		y = (int)((waterLevel - 3) * Random_Float(&rnd) * Random_Float(&rnd));
		NotchyGen_FloodFill(World_Pack(x, y, z), BLOCK_STILL_LAVA);
	}
}

static void NotchyGen_CreateSurfaceLayer(void) {	
	int hIndex = 0, index;
	BlockRaw above;
	int x, y, z;
#if CC_BUILD_MAXSTACK <= (16 * 1024)
	struct NoiseBuffer { 
		struct OctaveNoise n1, n2;
	};
	struct NoiseBuffer* buf = TempMem_Alloc(sizeof(struct NoiseBuffer));
	struct OctaveNoise* n1 = &buf->n1;
	struct OctaveNoise* n2 = &buf->n2;
#else
	struct OctaveNoise _n1, _n2;
	struct OctaveNoise* n1 = &_n1;
	struct OctaveNoise* n2 = &_n2;
#endif

	OctaveNoise_Init(n1, &rnd, 8);
	OctaveNoise_Init(n2, &rnd, 8);

	Gen_CurrentState = "Creating surface";
	for (z = 0; z < World.Length; z++) {
		Gen_CurrentProgress = (float)z / World.Length;

		for (x = 0; x < World.Width; x++) {
			y = heightmap[hIndex++];
			if (y < 0 || y >= World.Height) continue;

			index = World_Pack(x, y, z);
			above = y >= World.MaxY ? BLOCK_AIR : Gen_Blocks[index + World.OneY];

			/* TODO: update heightmap */
			if (above == BLOCK_STILL_WATER && (OctaveNoise_Calc(n2, (float)x, (float)z) > 12)) {
				Gen_Blocks[index] = BLOCK_GRAVEL;
			} else if (above == BLOCK_AIR) {
				Gen_Blocks[index] = (y <= waterLevel && (OctaveNoise_Calc(n1, (float)x, (float)z) > 8)) ? BLOCK_SAND : BLOCK_GRASS;
			}
		}
	}
}

static void NotchyGen_PlantFlowers(void) {
	int numPatches;
	BlockRaw block;
	int patchX,  patchZ;
	int flowerX, flowerY, flowerZ;
	int i, j, k, index;

	if (Game_Version.Version < VERSION_0023) return;
	numPatches       = World.Width * World.Length / 3000;
	Gen_CurrentState = "Planting flowers";

	for (i = 0; i < numPatches; i++) {
		Gen_CurrentProgress = (float)i / numPatches;

		block  = (BlockRaw)(BLOCK_DANDELION + Random_Next(&rnd, 2));
		patchX = Random_Next(&rnd, World.Width);
		patchZ = Random_Next(&rnd, World.Length);

		for (j = 0; j < 10; j++) {
			flowerX = patchX; flowerZ = patchZ;
			for (k = 0; k < 5; k++) {
				flowerX += Random_Next(&rnd, 6) - Random_Next(&rnd, 6);
				flowerZ += Random_Next(&rnd, 6) - Random_Next(&rnd, 6);

				if (!World_ContainsXZ(flowerX, flowerZ)) continue;
				flowerY = heightmap[flowerZ * World.Width + flowerX] + 1;
				if (flowerY <= 0 || flowerY >= World.Height) continue;

				index = World_Pack(flowerX, flowerY, flowerZ);
				if (Gen_Blocks[index] == BLOCK_AIR && Gen_Blocks[index - World.OneY] == BLOCK_GRASS)
					Gen_Blocks[index] = block;
			}
		}
	}
}

static void NotchyGen_PlantMushrooms(void) {
	int numPatches, groundHeight;
	BlockRaw block;
	int patchX, patchY, patchZ;
	int mushX,  mushY,  mushZ;
	int i, j, k, index;

	if (Game_Version.Version < VERSION_0023) return;
	numPatches       = World.Volume / 2000;
	Gen_CurrentState = "Planting mushrooms";

	for (i = 0; i < numPatches; i++) {
		Gen_CurrentProgress = (float)i / numPatches;

		block  = (BlockRaw)(BLOCK_BROWN_SHROOM + Random_Next(&rnd, 2));
		patchX = Random_Next(&rnd, World.Width);
		patchY = Random_Next(&rnd, World.Height);
		patchZ = Random_Next(&rnd, World.Length);

		for (j = 0; j < 20; j++) {
			mushX = patchX; mushY = patchY; mushZ = patchZ;
			for (k = 0; k < 5; k++) {
				mushX += Random_Next(&rnd, 6) - Random_Next(&rnd, 6);
				mushZ += Random_Next(&rnd, 6) - Random_Next(&rnd, 6);
				mushY += Random_Next(&rnd, 2) - Random_Next(&rnd, 2);

				if (!World_ContainsXZ(mushX, mushZ)) continue;
				groundHeight = heightmap[mushZ * World.Width + mushX];
				if (mushY <= 0 || mushY >= (groundHeight - 1)) continue;

				index = World_Pack(mushX, mushY, mushZ);
				if (Gen_Blocks[index] == BLOCK_AIR && Gen_Blocks[index - World.OneY] == BLOCK_STONE)
					Gen_Blocks[index] = block;
			}
		}
	}
}

static void NotchyGen_PlantTrees(void) {
	int numPatches;
	int patchX, patchZ;
	int treeX, treeY, treeZ;
	int treeHeight, index, count;
	BlockRaw under;
	int i, j, k, m;

	IVec3 coords[TREE_MAX_COUNT];
	BlockRaw blocks[TREE_MAX_COUNT];

	Tree_Blocks = Gen_Blocks;
	Tree_Rnd    = &rnd;

	numPatches       = World.Width * World.Length / 4000;
	Gen_CurrentState = "Planting trees";
	for (i = 0; i < numPatches; i++) {
		Gen_CurrentProgress = (float)i / numPatches;

		patchX = Random_Next(&rnd, World.Width);
		patchZ = Random_Next(&rnd, World.Length);

		for (j = 0; j < 20; j++) {
			treeX = patchX; treeZ = patchZ;
			for (k = 0; k < 20; k++) {
				treeX += Random_Next(&rnd, 6) - Random_Next(&rnd, 6);
				treeZ += Random_Next(&rnd, 6) - Random_Next(&rnd, 6);

				if (!World_ContainsXZ(treeX, treeZ) || Random_Float(&rnd) >= 0.25f) continue;
				treeY = heightmap[treeZ * World.Width + treeX] + 1;
				if (treeY >= World.Height) continue;
				treeHeight = 5 + Random_Next(&rnd, 3);

				index = World_Pack(treeX, treeY, treeZ);
				under = treeY > 0 ? Gen_Blocks[index - World.OneY] : BLOCK_AIR;

				if (under == BLOCK_GRASS && TreeGen_CanGrow(treeX, treeY, treeZ, treeHeight)) {
					count = TreeGen_Grow(treeX, treeY, treeZ, treeHeight, coords, blocks);

					for (m = 0; m < count; m++) {
						index = World_Pack(coords[m].x, coords[m].y, coords[m].z);
						Gen_Blocks[index] = blocks[m];
					}
				}
			}
		}
	}
}

static cc_bool NotchyGen_Prepare(int seed) {
	Random_Seed(&rnd, seed);
	waterLevel = World.Height / 2;	
	minHeight  = World.Height;

	heightmap  = (cc_int16*)Mem_TryAlloc(World.Width * World.Length, 2);
	return heightmap != NULL;
}

static void NotchyGen_Generate(void) {
	GEN_COOP_BEGIN
		GEN_COOP_STEP( 0, NotchyGen_CreateHeightmap() );
		GEN_COOP_STEP( 1, NotchyGen_CreateStrata() );
		GEN_COOP_STEP( 2, NotchyGen_CarveCaves() );
		GEN_COOP_STEP( 3, NotchyGen_CarveOreVeins(0.9f, "Carving coal ore", BLOCK_COAL_ORE) );
		GEN_COOP_STEP( 4, NotchyGen_CarveOreVeins(0.7f, "Carving iron ore", BLOCK_IRON_ORE) );
		GEN_COOP_STEP( 5, NotchyGen_CarveOreVeins(0.5f, "Carving gold ore", BLOCK_GOLD_ORE) );

		GEN_COOP_STEP( 6, NotchyGen_FloodFillWaterBorders() );
		GEN_COOP_STEP( 7, NotchyGen_FloodFillWater() );
		GEN_COOP_STEP( 8, NotchyGen_FloodFillLava() );

		GEN_COOP_STEP( 9, NotchyGen_CreateSurfaceLayer() );
		GEN_COOP_STEP(10, NotchyGen_PlantFlowers() );
		GEN_COOP_STEP(11, NotchyGen_PlantMushrooms() );
		GEN_COOP_STEP(12, NotchyGen_PlantTrees() );
	GEN_COOP_END

	Mem_Free(heightmap);
	heightmap = NULL;
	gen_done  = true;
}

const struct MapGenerator NotchyGen = {
	NotchyGen_Prepare,
	NotchyGen_Generate
};


/*########################################################################################################################*
*----------------------------------------------------Tree generation------------------------------------------------------*
*#########################################################################################################################*/
BlockRaw* Tree_Blocks;
RNGState* Tree_Rnd;

cc_bool TreeGen_CanGrow(int treeX, int treeY, int treeZ, int treeHeight) {
	int baseHeight = treeHeight - 4;
	int index;
	int x, y, z;

	/* check tree base */
	for (y = treeY; y < treeY + baseHeight; y++) {
		for (z = treeZ - 1; z <= treeZ + 1; z++) {
			for (x = treeX - 1; x <= treeX + 1; x++) {

				if (!World_Contains(x, y, z)) return false;
				index = World_Pack(x, y, z);
				if (Tree_Blocks[index] != BLOCK_AIR) return false;
			}
		}
	}

	/* and also check canopy */
	for (y = treeY + baseHeight; y < treeY + treeHeight; y++) {
		for (z = treeZ - 2; z <= treeZ + 2; z++) {
			for (x = treeX - 2; x <= treeX + 2; x++) {

				if (!World_Contains(x, y, z)) return false;
				index = World_Pack(x, y, z);
				if (Tree_Blocks[index] != BLOCK_AIR) return false;
			}
		}
	}
	return true;
}

#define TreeGen_Place(xVal, yVal, zVal, block)\
coords[count].x = (xVal); coords[count].y = (yVal); coords[count].z = (zVal);\
blocks[count] = block; count++;

int TreeGen_Grow(int treeX, int treeY, int treeZ, int height, IVec3* coords, BlockRaw* blocks) {
	int topStart = treeY + (height - 2);
	int count = 0;
	int xx, zz, x, y, z;

	/* leaves bottom layer */
	for (y = treeY + (height - 4); y < topStart; y++) {
		for (zz = -2; zz <= 2; zz++) {
			for (xx = -2; xx <= 2; xx++) {
				x = treeX + xx; z = treeZ + zz;

				if (Math_AbsI(xx) == 2 && Math_AbsI(zz) == 2) {
					if (Random_Float(Tree_Rnd) >= 0.5f) {
						TreeGen_Place(x, y, z, BLOCK_LEAVES);
					}
				} else {
					TreeGen_Place(x, y, z, BLOCK_LEAVES);
				}
			}
		}
	}

	/* leaves top layer */
	for (; y < treeY + height; y++) {
		for (zz = -1; zz <= 1; zz++) {
			for (xx = -1; xx <= 1; xx++) {
				x = xx + treeX; z = zz + treeZ;

				if (xx == 0 || zz == 0) {
					TreeGen_Place(x, y, z, BLOCK_LEAVES);
				} else if (y == topStart && Random_Float(Tree_Rnd) >= 0.5f) {
					TreeGen_Place(x, y, z, BLOCK_LEAVES);
				}
			}
		}
	}

	/* place trunk */
	for (y = 0; y < height - 1; y++) {
		TreeGen_Place(treeX, treeY + y, treeZ, BLOCK_LOG);
	}

	/* then place dirt */
	TreeGen_Place(treeX, treeY - 1, treeZ, BLOCK_DIRT);

	return count;
}


/*########################################################################################################################*
*---------------------------------------------------Infinite map gen------------------------------------------------------*
*#########################################################################################################################*/
/* The map held in memory acts as a 'window' into an endless world. Terrain is a pure function of */
/* (seed, global x, global z), so any part of the world can be regenerated at any time. When the   */
/* player walks close to the window's edge, the window is scrolled in whole-chunk steps, the new   */
/* strips are generated (or restored if the player edited them earlier) and all entities are moved. */
cc_bool Infinite_Enabled;
int Infinite_OriginX, Infinite_OriginZ;

#define INF_SEA_LEVEL 48
#define INF_MARGIN    64  /* scroll when the player gets this close to the window edge */

struct InfChunk { int cx, cz; BlockRaw* data; struct InfChunk* next; };
#define INF_BUCKETS 1024

static struct OctaveNoise inf_cont, inf_hills, inf_rough, inf_mount, inf_temp;
static struct OctaveNoise inf_cA, inf_cB, inf_cC;
static int inf_seed;
static cc_uint8* inf_dirty;
static struct InfChunk* inf_store[INF_BUCKETS];
static BlockRaw* inf_dst;

/* --- deterministic hashing --- */
static cc_uint32 Inf_Hash(int x, int y, int z, int salt) {
	cc_uint32 h = (cc_uint32)inf_seed * 374761393u + (cc_uint32)salt * 668265263u;
	h ^= (cc_uint32)x * 2654435761u;  h = (h << 13) | (h >> 19);
	h ^= (cc_uint32)y * 1597334677u;  h = (h << 11) | (h >> 21);
	h ^= (cc_uint32)z * 3266489917u;  h *= 2246822519u;
	h ^= h >> 15; h *= 3266489917u; h ^= h >> 13;
	return h;
}

/* --- terrain shape --- */
static int Inf_Height(int gx, int gz) {
	float cont  = OctaveNoise_Calc(&inf_cont,  gx * 0.08f, gz * 0.08f);  /* continents/oceans */
	float hills = OctaveNoise_Calc(&inf_hills, gx * 0.15f, gz * 0.15f);  /* rolling hills     */
	float rough = OctaveNoise_Calc(&inf_rough, gx * 0.5f,  gz * 0.5f);   /* small bumps       */
	float mount = OctaveNoise_Calc(&inf_mount, gx * 0.05f, gz * 0.05f);  /* mountain ranges   */
	float h = INF_SEA_LEVEL + 4.0f + cont * 2.2f + hills * 0.6f + rough * 0.9f;

	if (mount > 1.0f) {
		float m = mount - 1.0f;
		h += m * m * 5.0f + m * 10.0f;
	}
	/* flatten sea floor a little so oceans aren't pits */
	if (h < INF_SEA_LEVEL - 14) h = INF_SEA_LEVEL - 14 + (h - (INF_SEA_LEVEL - 14)) * 0.3f;

	if (h < 3) h = 3;
	if (h > World.Height - 8) h = (float)(World.Height - 8);
	return (int)h;
}

static float Inf_Temperature(int gx, int gz) {
	return OctaveNoise_Calc(&inf_temp, gx * 0.05f, gz * 0.05f);
}

static cc_bool Inf_IsCave(int gx, int y, int gz) {
	/* tunnels form where two noise 'sheets' are both close to zero */
	float a = OctaveNoise_Calc(&inf_cA, gx * 0.12f + y * 0.05f, gz * 0.12f);
	float b, c;
	if (Math_AbsF(a) > 0.16f) return false;
	b = OctaveNoise_Calc(&inf_cB, gx * 0.12f, y * 0.14f + gz * 0.05f);
	if (Math_AbsF(b) < 0.16f) return true;
	c = OctaveNoise_Calc(&inf_cC, gz * 0.1f + y * 0.08f, gx * 0.1f);
	return Math_AbsF(c) < 0.08f && y < INF_SEA_LEVEL - 6;
}

static BlockRaw Inf_Ore(int gx, int y, int gz) {
	/* ores form small 2x2x2 clumps */
	cc_uint32 h = Inf_Hash(gx >> 1, y >> 1, gz >> 1, 77);
	if (y < 40 && (h % 400) == 0) return BLOCK_COAL_ORE;
	if (y < 30 && (h % 700) == 1) return BLOCK_IRON_ORE;
	if (y < 18 && (h % 1500) == 2) return BLOCK_GOLD_ORE;
	if (y < 45 && (h % 500) == 3) return BLOCK_GRAVEL;
	return BLOCK_STONE;
}

enum { INF_BIOME_PLAINS, INF_BIOME_FOREST, INF_BIOME_DESERT, INF_BIOME_SNOW };
static int Inf_Biome(int gx, int gz, int height) {
	float t = Inf_Temperature(gx, gz);
	if (height > INF_SEA_LEVEL + 40) return INF_BIOME_SNOW;
	if (t > 1.1f)  return INF_BIOME_DESERT;
	if (t < -1.3f) return INF_BIOME_SNOW;
	if (t < 0.4f && t > -0.6f) return INF_BIOME_FOREST;
	return INF_BIOME_PLAINS;
}

#define INF_PAD 3
#define INF_TILE (16 + INF_PAD * 2)

static void Inf_SetBlock(int wx, int y, int wz, BlockRaw b) {
	inf_dst[(y * World.Length + wz) * World.Width + wx] = b;
}
static BlockRaw Inf_GetBlock(int wx, int y, int wz) {
	return inf_dst[(y * World.Length + wz) * World.Width + wx];
}

/* Generates the 16x16 column of chunk (gcx, gcz) into the window, with its minimum corner at (wx0, wz0) */
static void Inf_GenChunk(int gcx, int gcz, int wx0, int wz0) {
	int heights[INF_TILE][INF_TILE];
	int biomes[INF_TILE][INF_TILE];
	int x, z, y, tx, tz;
	int gx0 = gcx * 16, gz0 = gcz * 16;

	for (tz = 0; tz < INF_TILE; tz++) {
		for (tx = 0; tx < INF_TILE; tx++) {
			int gx = gx0 + tx - INF_PAD, gz = gz0 + tz - INF_PAD;
			heights[tz][tx] = Inf_Height(gx, gz);
			biomes[tz][tx]  = Inf_Biome(gx, gz, heights[tz][tx]);
		}
	}

	for (z = 0; z < 16; z++) {
		for (x = 0; x < 16; x++) {
			int gx = gx0 + x, gz = gz0 + z;
			int h = heights[z + INF_PAD][x + INF_PAD];
			int biome = biomes[z + INF_PAD][x + INF_PAD];
			int wx = wx0 + x, wz = wz0 + z;
			BlockRaw top, filler;
			int dirtDepth = 3 + (int)(Inf_Hash(gx, 0, gz, 5) % 2);

			if (biome == INF_BIOME_DESERT || h <= INF_SEA_LEVEL + 1) {
				top = BLOCK_SAND; filler = BLOCK_SAND;
				if (h < INF_SEA_LEVEL - 3) { top = BLOCK_GRAVEL; filler = BLOCK_DIRT; }
			} else if (biome == INF_BIOME_SNOW && h > INF_SEA_LEVEL + 30) {
				top = BLOCK_SNOW; filler = BLOCK_STONE;
			} else {
				top = BLOCK_GRASS; filler = BLOCK_DIRT;
			}
			if (h > INF_SEA_LEVEL + 50) { top = BLOCK_STONE; filler = BLOCK_STONE; }

			for (y = 0; y < World.Height; y++) {
				BlockRaw b;
				if (y == 0) {
					b = BLOCK_STILL_LAVA;
				} else if (y > h) {
					b = (y <= INF_SEA_LEVEL) ? BLOCK_STILL_WATER : BLOCK_AIR;
					if (b == BLOCK_STILL_WATER && y == INF_SEA_LEVEL && biome == INF_BIOME_SNOW && h < INF_SEA_LEVEL - 1 &&
						Inf_Temperature(gx, gz) < -1.6f) b = BLOCK_ICE;
				} else if (y == h) {
					b = top;
				} else if (y > h - dirtDepth) {
					b = filler;
				} else {
					b = Inf_Ore(gx, y, gz);
					if (y > 2 && y < h - 3 && Inf_IsCave(gx, y, gz)) b = (y < 9) ? BLOCK_STILL_LAVA : BLOCK_AIR;
				}
				Inf_SetBlock(wx, y, wz, b);
			}
		}
	}

	/* trees and flowers: decided per column from hashes, so neighbouring chunks agree about trees overlapping borders */
	for (tz = 0; tz < INF_TILE; tz++) {
		for (tx = 0; tx < INF_TILE; tx++) {
			int gx = gx0 + tx - INF_PAD, gz = gz0 + tz - INF_PAD;
			int h = heights[tz][tx], biome = biomes[tz][tx];
			cc_uint32 hash = Inf_Hash(gx, 1, gz, 9);
			int chance, treeH, dx, dz, dy;

			if (h <= INF_SEA_LEVEL + 1 || h > INF_SEA_LEVEL + 38) continue;
			if (biome == INF_BIOME_DESERT || biome == INF_BIOME_SNOW) continue;

			chance = (biome == INF_BIOME_FOREST) ? 28 : 160;
			if ((hash % chance) != 0) {
				/* flowers on grass inside this chunk */
				if (tx >= INF_PAD && tx < INF_PAD + 16 && tz >= INF_PAD && tz < INF_PAD + 16) {
					int wx = wx0 + tx - INF_PAD, wz = wz0 + tz - INF_PAD;
					if ((hash >> 8) % 90 == 0 && Inf_GetBlock(wx, h, wz) == BLOCK_GRASS && h + 1 < World.Height)
						Inf_SetBlock(wx, h + 1, wz, ((hash >> 16) & 1) ? BLOCK_ROSE : BLOCK_DANDELION);
				}
				continue;
			}

			/* avoid trees right next to each other */
			treeH = 5 + (int)((hash >> 12) % 3);
			if (h + treeH + 2 >= World.Height) continue;

			/* trunk (only if inside this chunk) */
			{
				int wxT = wx0 + tx - INF_PAD, wzT = wz0 + tz - INF_PAD;
				if (tx >= INF_PAD && tx < INF_PAD + 16 && tz >= INF_PAD && tz < INF_PAD + 16) {
					if (Inf_GetBlock(wxT, h, wzT) == BLOCK_GRASS) {
						Inf_SetBlock(wxT, h, wzT, BLOCK_DIRT);
						for (dy = 1; dy <= treeH - 1; dy++) Inf_SetBlock(wxT, h + dy, wzT, BLOCK_LOG);
					}
				}
			}
			if (biomes[tz][tx] == INF_BIOME_DESERT) continue;

			/* canopy: leaves around top, clipped to this chunk */
			for (dy = treeH - 4; dy <= treeH; dy++) {
				int r = (dy >= treeH - 1) ? 1 : 2;
				for (dz = -r; dz <= r; dz++) {
					for (dx = -r; dx <= r; dx++) {
						int lx = tx + dx - INF_PAD, lz = tz + dz - INF_PAD;
						int wx, wz, yy = h + dy;
						if (lx < 0 || lx >= 16 || lz < 0 || lz >= 16) continue;
						if (r == 2 && Math_AbsI(dx) == 2 && Math_AbsI(dz) == 2 && (Inf_Hash(gx + dx, dy, gz + dz, 3) & 1)) continue;
						if (r == 1 && Math_AbsI(dx) == 1 && Math_AbsI(dz) == 1 && dy == treeH) continue;
						wx = wx0 + lx; wz = wz0 + lz;
						if (yy < World.Height && Inf_GetBlock(wx, yy, wz) == BLOCK_AIR)
							Inf_SetBlock(wx, yy, wz, BLOCK_LEAVES);
					}
				}
			}
		}
	}
}

/* --- storage of player-modified chunks that have scrolled out of the window --- */
static struct InfChunk** Inf_Bucket(int cx, int cz) {
	cc_uint32 h = (cc_uint32)cx * 73856093u ^ (cc_uint32)cz * 19349663u;
	return &inf_store[h % INF_BUCKETS];
}

static struct InfChunk* Inf_FindStored(int cx, int cz) {
	struct InfChunk* c;
	for (c = *Inf_Bucket(cx, cz); c; c = c->next) {
		if (c->cx == cx && c->cz == cz) return c;
	}
	return NULL;
}

/* Copies chunk column with window chunk coords (wcx, wcz) out of the window into the store */
static void Inf_SaveChunk(int wcx, int wcz) {
	int gcx = (Infinite_OriginX >> 4) + wcx, gcz = (Infinite_OriginZ >> 4) + wcz;
	struct InfChunk* c = Inf_FindStored(gcx, gcz);
	int x, y, z, i = 0;
	if (!c) {
		struct InfChunk** bucket = Inf_Bucket(gcx, gcz);
		c = (struct InfChunk*)Mem_TryAlloc(1, sizeof(struct InfChunk));
		if (!c) return;
		c->data = (BlockRaw*)Mem_TryAlloc(16 * 16 * World.Height, 1);
		if (!c->data) { Mem_Free(c); return; }
		c->cx = gcx; c->cz = gcz;
		c->next = *bucket; *bucket = c;
	}
	for (y = 0; y < World.Height; y++) {
		for (z = 0; z < 16; z++) {
			for (x = 0; x < 16; x++) {
				c->data[i++] = World.Blocks[World_Pack(wcx * 16 + x, y, wcz * 16 + z)];
			}
		}
	}
}

static void Inf_LoadOrGenChunk(int wcx, int wcz) {
	int gcx = (Infinite_OriginX >> 4) + wcx, gcz = (Infinite_OriginZ >> 4) + wcz;
	struct InfChunk* c = Inf_FindStored(gcx, gcz);
	int x, y, z, i = 0;

	inf_dst = World.Blocks;
	if (!c) { Inf_GenChunk(gcx, gcz, wcx * 16, wcz * 16); return; }

	for (y = 0; y < World.Height; y++) {
		for (z = 0; z < 16; z++) {
			for (x = 0; x < 16; x++) {
				World.Blocks[World_Pack(wcx * 16 + x, y, wcz * 16 + z)] = c->data[i++];
			}
		}
	}
	inf_dirty[wcx + wcz * World.ChunksX] = 1;
}

static void Inf_FreeStore(void) {
	int i;
	for (i = 0; i < INF_BUCKETS; i++) {
		struct InfChunk* c = inf_store[i];
		while (c) {
			struct InfChunk* next = c->next;
			Mem_Free(c->data); Mem_Free(c);
			c = next;
		}
		inf_store[i] = NULL;
	}
}

void Infinite_Reset(void) {
	Infinite_Enabled = false;
	Mem_Free(inf_dirty); inf_dirty = NULL;
	Inf_FreeStore();
}

void Infinite_OnBlockChanged(int x, int z) {
	if (!Infinite_Enabled || !inf_dirty) return;
	inf_dirty[(x >> 4) + (z >> 4) * World.ChunksX] = 1;
}

/* --- initial generation --- */
static void Inf_InitNoise(int seed) {
	RNGState r;
	Random_Seed(&r, seed);
	OctaveNoise_Init(&inf_cont,  &r, 4);
	OctaveNoise_Init(&inf_hills, &r, 5);
	OctaveNoise_Init(&inf_rough, &r, 3);
	OctaveNoise_Init(&inf_mount, &r, 3);
	OctaveNoise_Init(&inf_temp,  &r, 3);
	OctaveNoise_Init(&inf_cA, &r, 2);
	OctaveNoise_Init(&inf_cB, &r, 2);
	OctaveNoise_Init(&inf_cC, &r, 2);
	inf_seed = seed;
}

static cc_bool InfiniteGen_Prepare(int seed) {
	int r, a, gx, gz, bestX = 0, bestZ = 0;
	RNGState rn;

	Infinite_Reset();
	if ((World.Width & 15) || (World.Length & 15)) return false;
	Inf_InitNoise(seed);

	/* start the player on land: spiral outwards from the origin until a decent spot is found */
	Random_Seed(&rn, seed + 1);
	gx = (int)Random_Next(&rn, 4000) - 2000;
	gz = (int)Random_Next(&rn, 4000) - 2000;
	bestX = gx; bestZ = gz;
	for (r = 0; r < 200; r++) {
		static const int dirs[8][2] = { {1,0},{-1,0},{0,1},{0,-1},{1,1},{-1,-1},{1,-1},{-1,1} };
		cc_bool found = false;
		for (a = 0; a < 8; a++) {
			int sx = gx + dirs[a][0] * r * 10;
			int sz = gz + dirs[a][1] * r * 10;
			int h  = Inf_Height(sx, sz);
			if (h > INF_SEA_LEVEL + 3 && h < INF_SEA_LEVEL + 14) { bestX = sx; bestZ = sz; found = true; break; }
		}
		if (found) break;
	}
	Infinite_OriginX = ((bestX - World.Width  / 2) >> 4) * 16;
	Infinite_OriginZ = ((bestZ - World.Length / 2) >> 4) * 16;

	inf_dirty = (cc_uint8*)Mem_TryAllocCleared(World.ChunksX * World.ChunksZ, 1);
	if (!inf_dirty) return false;

	/* edge water should line up with sea level, so the map border looks like an ocean */
	Env.EdgeHeight = INF_SEA_LEVEL;
	return true;
}

static void InfiniteGen_Generate(void) {
	int cx, cz;
	Gen_CurrentState = "Generating terrain";
	inf_dst = Gen_Blocks;

	for (cz = 0; cz < World.ChunksZ; cz++) {
		Gen_CurrentProgress = (float)cz / World.ChunksZ;
		for (cx = 0; cx < World.ChunksX; cx++) {
			Inf_GenChunk((Infinite_OriginX >> 4) + cx, (Infinite_OriginZ >> 4) + cz, cx * 16, cz * 16);
		}
	}
	Infinite_Enabled = true;
	gen_done = true;
}

const struct MapGenerator InfiniteGen = { InfiniteGen_Prepare, InfiniteGen_Generate };

#define INF_WIDTH  256
#define INF_HEIGHT 128
void Gen_StartInfinite(int seed) {
	Gen_Start(&InfiniteGen, seed, INF_WIDTH, INF_HEIGHT, INF_WIDTH);
}

/* --- scrolling the window --- */
static void Inf_ShiftEntities(float dx, float dz) {
	int i;
	for (i = 0; i < ENTITIES_MAX_COUNT; i++) {
		struct Entity* e = Entities.List[i];
		if (!e) continue;
		e->Position.x -= dx; e->Position.z -= dz;
		e->prev.pos.x -= dx; e->prev.pos.z -= dz;
		e->next.pos.x -= dx; e->next.pos.z -= dz;
	}
	for (i = 0; i < Game_NumStates; i++) {
		LocalPlayer_Instances[i].Spawn.x -= dx;
		LocalPlayer_Instances[i].Spawn.z -= dz;
	}
}

static void Inf_ShiftBlocks(BlockRaw* blocks, int dx, int dz) {
	int W = World.Width, L = World.Length, H = World.Height;
	int y, z, zBeg, zEnd, zStep;
	int xSrc = dx > 0 ? dx : 0;      /* first source x copied */
	int xDst = dx > 0 ? 0  : -dx;    /* first dest x written  */
	int count = W - (dx > 0 ? dx : -dx);

	if (dz > 0) { zBeg = 0;     zEnd = L;  zStep = 1;  }
	else        { zBeg = L - 1; zEnd = -1; zStep = -1; }

	for (y = 0; y < H; y++) {
		for (z = zBeg; z != zEnd; z += zStep) {
			int sz = z + dz;
			if (sz < 0 || sz >= L || count <= 0) continue;
			Mem_Move(blocks + (y * L + z) * W + xDst, blocks + (y * L + sz) * W + xSrc, count);
		}
	}
}

static void Inf_Scroll(int dx, int dz) {
	int cxN = World.ChunksX, czN = World.ChunksZ;
	int dcx = dx >> 4, dcz = dz >> 4;
	int cx, cz;
	cc_uint8* newDirty;

	/* save edited chunks that are about to scroll out */
	for (cz = 0; cz < czN; cz++) {
		for (cx = 0; cx < cxN; cx++) {
			int nx = cx - dcx, nz = cz - dcz;
			if ((nx < 0 || nx >= cxN || nz < 0 || nz >= czN) && inf_dirty[cx + cz * cxN]) Inf_SaveChunk(cx, cz);
		}
	}

	newDirty = (cc_uint8*)Mem_TryAllocCleared(cxN * czN, 1);
	if (!newDirty) return;
	for (cz = 0; cz < czN; cz++) {
		for (cx = 0; cx < cxN; cx++) {
			int nx = cx - dcx, nz = cz - dcz;
			if (nx < 0 || nx >= cxN || nz < 0 || nz >= czN) continue;
			newDirty[nx + nz * cxN] = inf_dirty[cx + cz * cxN];
		}
	}
	Mem_Free(inf_dirty); inf_dirty = newDirty;

	Inf_ShiftBlocks(World.Blocks, dx, dz);
#ifdef EXTENDED_BLOCKS
	if (World.Blocks2 != World.Blocks) Inf_ShiftBlocks(World.Blocks2, dx, dz);
#endif
	Infinite_OriginX += dx; Infinite_OriginZ += dz;

	/* fill the newly exposed chunk columns */
	for (cz = 0; cz < czN; cz++) {
		for (cx = 0; cx < cxN; cx++) {
			int sx = cx + dcx, sz = cz + dcz;
			if (sx >= 0 && sx < cxN && sz >= 0 && sz < czN) continue;
			Inf_LoadOrGenChunk(cx, cz);
#ifdef EXTENDED_BLOCKS
			if (World.Blocks2 != World.Blocks) {
				int x, y, z;
				for (y = 0; y < World.Height; y++)
					for (z = 0; z < 16; z++)
						for (x = 0; x < 16; x++)
							World.Blocks2[World_Pack(cx * 16 + x, y, cz * 16 + z)] = 0;
			}
#endif
		}
	}

	Inf_ShiftEntities((float)dx, (float)dz);

	/* everything that caches map positions has to be rebuilt */
	if (Weather_Heightmap) {
		int i;
		for (i = 0; i < World.Width * World.Length; i++) Weather_Heightmap[i] = Int16_MaxValue;
	}
	Physics_SetEnabled(Physics.Enabled); /* also clears pending water/lava updates */
	Lighting.Refresh();
	MapRenderer_Refresh();
}

void Infinite_Tick(void) {
	struct Entity* p;
	int dx, dz, px, pz, half;
	if (!Infinite_Enabled || !World.Loaded || !World.Blocks || !inf_dirty) return;

	p = &Entities.CurPlayer->Base;
	px = (int)p->Position.x; pz = (int)p->Position.z;

	dx = 0; dz = 0;
	if (px < INF_MARGIN || px >= World.Width  - INF_MARGIN) {
		half = World.Width / 2;
		dx = ((px - half) / 16) * 16;
	}
	if (pz < INF_MARGIN || pz >= World.Length - INF_MARGIN) {
		half = World.Length / 2;
		dz = ((pz - half) / 16) * 16;
	}
	if (dx == 0 && dz == 0) return;

	/* never scroll by more than the whole window */
	if (dx >  World.Width  - 16) dx =  World.Width  - 16;
	if (dx < -World.Width  + 16) dx = -(World.Width  - 16);
	if (dz >  World.Length - 16) dz =  World.Length - 16;
	if (dz < -World.Length + 16) dz = -(World.Length - 16);
	Inf_Scroll(dx, dz);
}
