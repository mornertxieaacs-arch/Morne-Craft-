#ifndef CC_MOBS_H
#define CC_MOBS_H
#include "Core.h"
CC_BEGIN_HEADER

/* Singleplayer mobs with simple AI (wander, chase, flee, creeper fuse).
   Uses the standard entity system and the built-in mob models. */
struct IGameComponent;
extern struct IGameComponent Mobs_Component;

/* Tries to hit the mob the player is looking at. Returns true if a mob was hit. */
cc_bool Mobs_TryAttack(void);
/* Spawns mobs near the player (called every entity tick) */
void Mobs_Tick(void);

CC_END_HEADER
#endif
