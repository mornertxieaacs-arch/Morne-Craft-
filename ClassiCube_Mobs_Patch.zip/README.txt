ClassiCube mobs + mob AI patch (on top of your infinite-world source)
=====================================================================
New files : src/Mobs.c, src/Mobs.h
Edited    : src/Entity.c (spawn tick), src/Game.c (component), src/InputHandler.c (tap/click hits mobs),
            misc/android/app/CMakeLists.txt + src/ClassiCube.vcxproj (add Mobs.c to builds)

Copy these files over your source tree (same paths), commit, and run the "Build Android" GitHub workflow.

Mobs (singleplayer only): pig, sheep, chicken (wander, run away when hit);
zombie, spider (chase and shove you); skeleton (chases, then keeps its distance);
creeper (fuse, then blows a small hole and throws you back). Max 14 at a time, spawn 14-28 blocks away,
despawn when 52+ blocks away. Tapping/clicking a mob hits it.
Not included: inventory screen, health system, arrows.
